"""
文本分块 — 将长文档切分为适合向量检索的短片段
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Chunk:
    """文本块：编号 + 文本内容 + 元信息"""
    chunk_id: str
    text: str
    meta: dict


def chunk_text(
    text: str,
    *,
    chunk_size: int = 900,
    chunk_overlap: int = 150,
) -> list[Chunk]:
    """
    基于字符数的简单分块（带重叠）。
    校园政策文档格式多样，此方法作为基线已足够鲁棒。
    """
    clean = text.strip()
    if not clean:
        return []

    chunks: list[Chunk] = []
    start = 0
    idx = 0
    while start < len(clean):
        end = min(len(clean), start + chunk_size)
        piece = clean[start:end]
        chunk_id = f"c{idx:06d}"
        chunks.append(Chunk(chunk_id=chunk_id, text=piece, meta={"start": start, "end": end}))
        idx += 1
        if end == len(clean):
            break
        start = max(0, end - chunk_overlap)
    return chunks

