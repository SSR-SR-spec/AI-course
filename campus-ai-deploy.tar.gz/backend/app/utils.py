"""
工具函数：时间、ID 生成、文档去重哈希、目录创建
"""

from __future__ import annotations

import hashlib
import os
import time
import uuid


def now_ms() -> int:
    """返回当前毫秒级时间戳"""
    return int(time.time() * 1000)


def new_turn_id() -> str:
    """生成一次对话轮次的唯一 ID"""
    return uuid.uuid4().hex


def stable_doc_id(source: str, content: str) -> str:
    """
    基于文档来源路径 + 内容生成稳定哈希 ID，
    用于导入时去重（相同内容不重复入库）
    """
    h = hashlib.sha256()
    h.update(source.encode("utf-8"))
    h.update(b"\n")
    h.update(content.encode("utf-8", errors="ignore"))
    return h.hexdigest()[:24]


def ensure_dir(path: str) -> None:
    """确保目录存在，不存在则创建"""
    os.makedirs(path, exist_ok=True)

