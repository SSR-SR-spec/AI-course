# Campus AI - 校园智能问答助手

基于 **FastAPI + FAISS + DeepSeek** 的校园知识问答系统。
支持多智能体路由（学术/生活/行政）和 RAG 检索，回答自动附带引用来源。

## 目录结构

```
├── backend/                 # FastAPI 后端
│   ├── app/
│   │   ├── main.py          # API 入口
│   │   ├── config.py        # 配置管理
│   │   ├── schemas.py       # 数据模型
│   │   ├── citations.py     # 引用格式化
│   │   ├── sessions.py      # 会话存储
│   │   ├── utils.py         # 工具函数
│   │   ├── settings.yaml    # 配置文件
│   │   ├── rag/             # RAG 知识库
│   │   │   ├── kb.py        # FAISS 向量库操作
│   │   │   ├── chunking.py  # 文本分块
│   │   │   └── document_loader.py
│   │   └── llm/client.py    # 大模型调用客户端
│   ├── kb_semantic_v2/      # 构建好的知识库（含 FAISS 索引）
│   ├── app/infor/           # 源文档
│   ├── requirements.txt
│   └── scripts/download_embedding_model.py
├── frontend/
│   ├── chat.html            # 聊天页面（可直接浏览器打开）
│   └── assets/
├── Dockerfile               # Docker 构建文件
├── docker-compose.yml       # Docker 部署配置
└── .env.example             # 环境变量模板
```

## 快速开始（二选一）

### 方式一：直接部署（推荐，适合本地开发）

**环境要求：** Python 3.10+

```bash
# 1. 进入后端目录
cd backend

# 2. 创建虚拟环境
python -m venv .venv

# 3. 激活虚拟环境
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

# 4. 安装依赖（国内用清华镜像更快）
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt

# 5. 下载 embedding 模型（约 4.4GB，首次需要）
python scripts/download_embedding_model.py

# 6. 启动服务
uvicorn app.main:app --reload --port 8000

# 7. 打开浏览器
# API 文档:   http://127.0.0.1:8000/docs
# 聊天页面:   双击 frontend/chat.html
```

### 方式二：Docker 部署（适合服务器）

**环境要求：** Docker + Docker Compose

```bash
# 1. 配置 API Key
cp .env.example .env
# 编辑 .env 填入你的 DeepSeek API Key

# 2. 一键启动
docker compose up -d

# 3. 访问
# http://localhost:80
```

## 配置说明

### 1. 配置 API Key（不配则用 Mock 模式）

编辑 `backend/app/settings.local.yaml`（推荐，已 gitignore）：
```yaml
llm:
  openai_api_key: "sk-your-deepseek-api-key"
```

或使用环境变量：
```bash
export OPENAI_API_KEY="sk-your-deepseek-api-key"
```

### 2. 导入文档到知识库

启动服务后，发送请求导入文档：
```bash
curl -X POST "http://127.0.0.1:8000/ingest/local-folder" \
  -H "Content-Type: application/json" \
  -d '{"folder_path":"./app/infor"}'
```

### 3. 关键配置项（`backend/app/settings.yaml`）

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `llm.provider` | 模型提供商（mock/openai_compatible） | mock |
| `rag.top_k` | 检索返回的片段数 | 5 |
| `rag.min_score` | 最低相似度阈值 | 0.35 |
| `rag.chunk_size` | 文本分块大小（字符数） | 700 |
| `rag.chunk_overlap` | 分块重叠 | 120 |

## 接口说明

| 接口 | 方法 | 说明 |
|------|------|------|
| `/chat` | POST | 对话问答 |
| `/health` | GET | 健康检查 |
| `/kb/stats` | GET | 知识库统计 |
| `/ingest/local-folder` | POST | 导入文档 |

## 常见问题

**Q: 服务启动后页面无法访问？**
- 检查阿里云/云服务商的安全组是否放行了端口
- Docker 部署默认用 80 端口，直接部署默认用 8000 端口

**Q: 回答显示"Mock 模型"？**
- 未配置 API Key，系统自动降级到 Mock 模式
- 配置 `settings.local.yaml` 中的 `openai_api_key` 即可

**Q: 下载 embedding 模型很慢？**
- 国内建议设置环境变量 `export HF_ENDPOINT=https://hf-mirror.com`
- 或使用脚本下载：`python scripts/download_embedding_model.py`
