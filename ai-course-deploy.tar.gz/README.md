# Campus LLM-MAS + RAG Knowledge Service (Demo)

本仓库实现一个面向校园的 **多智能体（LLM-MAS）+ RAG** 知识服务平台：
- FastAPI 后端：对话接口、文档入库、向量检索、引用追溯、（可选）Redis 会话
- 多智能体：导航路由（Router）+ 学术/生活/行政 专业智能体 + 质量审核智能体
- RAG：本地文档构建知识库（FAISS），回答附带引用片段
- 前端：Gradio 演示界面 + React（Vite）简易聊天页

## 目录
- `backend/`：FastAPI + RAG + Agents
- `frontend/gradio_app.py`：Gradio 演示
- `frontend-react/`：React（Vite）简易聊天页

## 环境要求
- Python 3.10+
- （可选）Redis
- （可选）Node.js 18+（用于 React 前端）

## 1) 启动后端

在仓库根目录：

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

打开：`http://127.0.0.1:8000/docs`

## 2) 导入校园文档到知识库

把文档（`pdf/txt/md/html`）放到一个目录，例如 `D:\AI-course\backend\app\infor\`，然后调用入库：

```powershell
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8000/ingest/local-folder" `
  -ContentType "application/json" `
  -Body '{"folder_path":"F:/E/人工智能综合课程设计/AI-course/backend/app/infor"}'
```

## 3) Gradio 前端（推荐先用它验收）

另开一个终端：

```powershell
cd frontend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python gradio_app.py
```

## 4) React 前端（可选）

```powershell
cd frontend-react
npm install
npm run dev
```

## 模型配置（可选）

默认使用 `mock` 模型（无需 API Key，便于本地跑通流程）。

### 推荐：用配置文件（不需要命令行环境变量）

编辑：`backend/app/settings.yaml`

- 填入 DeepSeek 的 `openai_api_key`
- 配置 `openai_base_url` / `openai_model`
- 配置 RAG 参数（片段数量、片段长度、chunk 切分等）

也支持可选覆盖文件 `backend/app/settings.local.yaml`（同名结构，优先级更高）。

可参考模板：`backend/app/settings.local.example.yaml`（复制为 `settings.local.yaml` 后填入 key）。

> 说明：如果 `llm.provider=openai_compatible` 但 `openai_api_key` 为空，后端会自动回退到 `mock`，保证项目仍可本地运行。

### DeepSeek（OpenAI 兼容）示例（写在 settings.yaml）

> 具体 Base URL / Model 名称以 DeepSeek 控制台文档为准；仓库内 `settings.yaml` 已给出一种常见默认值。

### RAG 输出太长 / Gradio 一直转圈（常见原因与调参）

- **一直转圈**：多数是在等外部大模型返回；也可能是首次下载 embedding 模型（网络不通会重试）。
- **回答把整篇文档贴出来**：通常是上下文太大 + 模型没有遵守“摘要式回答”。本项目已在后端加了更强的约束，并限制检索片段总量。

直接在 `backend/app/settings.yaml` 的 `rag:` 段落调整：

- `max_snippets`
- `max_chars_per_snippet`
- `max_context_chars`
- `chunk_size` / `chunk_overlap`

### Gradio 后端地址（不需要环境变量）

编辑：`frontend/gradio_app.py` 里的 `BACKEND_URL`。

## 关键接口
- `POST /chat`：对话（返回结构化结果：路由、答案、引用、审核结论）
- `POST /ingest/local-folder`：从本地文件夹导入构建索引
- `GET /kb/stats`：知识库统计
- `GET /trace/{turn_id}`：该轮的可追溯信息（路由、检索、审核）

## 仓库说明

本仓库基于 GitHub [remote_repo](https://github.com/cxk-veb/remote_repo) 演进，已合并早期练习提交（`hello.txt`、`test.txt`），并在此基础上完成校园智能问答系统开发。
