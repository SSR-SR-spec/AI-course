from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.config import Settings


@dataclass
class LLMResult:
    content: str
    raw: dict[str, Any]


class LLMClient:
    def __init__(self, settings: Settings):
        self.settings = settings

    async def complete(self, *, system: str, user: str) -> LLMResult:
        if self.settings.llm_provider == "mock":
            return LLMResult(
                content=_mock_answer(system=system, user=user),
                raw={"provider": "mock"},
            )

        if self.settings.llm_provider == "openai_compatible":
            return await _openai_compatible_complete(
                api_key=self.settings.openai_api_key,
                base_url=self.settings.openai_base_url,
                model=self.settings.openai_model,
                system=system,
                user=user,
                timeout_s=self.settings.llm_timeout_s,
                max_output_tokens=self.settings.llm_max_output_tokens,
            )

        raise ValueError(f"Unknown LLM_PROVIDER: {self.settings.llm_provider}")


def _mock_answer(*, system: str, user: str) -> str:
    # Deterministic-ish baseline: echoes structured answer format.
    # Useful to validate RAG + workflow locally without external API.
    return (
        "（Mock 模型）\n"
        "我会基于提供的引用片段给出结论；若引用不足，我会提示需要人工确认。\n\n"
        "说明：Mock 模式不会调用外部大模型，因此不会真正“理解”文档内容；"
        "接入 DeepSeek 后才会基于引用片段生成摘要式回答。\n"
    )


async def _openai_compatible_complete(
    *,
    api_key: str | None,
    base_url: str | None,
    model: str,
    system: str,
    user: str,
    timeout_s: int,
    max_output_tokens: int,
) -> LLMResult:
    from litellm import acompletion

    if not api_key:
        raise ValueError("OPENAI_API_KEY is required for openai_compatible provider.")

    # litellm supports OpenAI-compatible providers via `api_base`.
    # Some users set OPENAI_BASE_URL without trailing `/v1` — both are OK for most gateways.
    try:
        litellm_model = _normalize_litellm_model(model=model, api_base=base_url)
        resp = await acompletion(
            model=litellm_model,
            api_key=api_key,
            api_base=base_url,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0.2,
            timeout=timeout_s,
            max_tokens=max_output_tokens,
        )
    except Exception as e:
        raise RuntimeError(
            "LLM request failed. Check `openai_base_url`, `openai_model`, network connectivity, "
            f"and API key validity. Underlying error: {type(e).__name__}: {e}"
        ) from e

    content = _extract_openai_compatible_content(resp)
    return LLMResult(
        content=content,
        raw={"provider": "openai_compatible", "model": litellm_model, "resp": resp},
    )


def _normalize_litellm_model(*, model: str, api_base: str | None) -> str:
    """
    litellm requires an explicit provider prefix for many models, e.g. `deepseek/deepseek-chat`.
    Users often configure only `deepseek-chat` when using OpenAI-compatible endpoints.
    """
    m = (model or "").strip()
    if not m:
        raise ValueError("openai_model is empty")

    if "/" in m:
        return m

    base = (api_base or "").lower()
    if "deepseek.com" in base:
        # Common DeepSeek chat model id
        if m in {"deepseek", "deepseek-chat", "deepseek_chat"}:
            return "deepseek/deepseek-chat"
        if m.startswith("deepseek-"):
            return f"deepseek/{m}"

    return m


def _extract_openai_compatible_content(resp: Any) -> str:
    """
    litellm / provider responses may be dict-like or object-like depending on version.
    """
    # dict path
    try:
        if isinstance(resp, dict):
            choices = resp.get("choices") or []
            if not choices:
                raise KeyError("missing choices")
            msg = (choices[0] or {}).get("message") or {}
            c = msg.get("content")
            if isinstance(c, str) and c.strip():
                return c
    except Exception:
        pass

    # object path
    try:
        choices = getattr(resp, "choices", None)
        if choices:
            ch0 = choices[0]
            message = getattr(ch0, "message", None)
            c = getattr(message, "content", None) if message is not None else None
            if isinstance(c, str) and c.strip():
                return c
    except Exception:
        pass

    raise RuntimeError(f"Unexpected LLM response shape: {type(resp).__name__}")

