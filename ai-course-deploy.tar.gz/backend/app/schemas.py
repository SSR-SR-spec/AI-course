from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str


class ChatRequest(BaseModel):
    session_id: str | None = None
    message: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class Citation(BaseModel):
    doc_id: str
    source: str
    chunk_id: str
    score: float
    snippet: str
    meta: dict[str, Any] = Field(default_factory=dict)


class AgentAnswer(BaseModel):
    agent: str
    answer: str
    citations: list[Citation] = Field(default_factory=list)


class AuditResult(BaseModel):
    passed: bool
    issues: list[str] = Field(default_factory=list)
    suggested_fix: str | None = None


class ChatResponse(BaseModel):
    turn_id: str
    session_id: str
    intent: str
    routed_agents: list[str]
    final_answer: str
    citations: list[Citation]
    audit: AuditResult
    debug: dict[str, Any] = Field(default_factory=dict)


class IngestFolderRequest(BaseModel):
    folder_path: str


class IngestResponse(BaseModel):
    added_documents: int
    added_chunks: int
    kb_dir: str
    files_scanned: int = 0
    note: str | None = None


class KBStats(BaseModel):
    documents: int
    chunks: int
    embedding_dim: int
    kb_dir: str

