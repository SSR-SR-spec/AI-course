from __future__ import annotations

import hashlib
import os
import time
import uuid


def now_ms() -> int:
    return int(time.time() * 1000)


def new_turn_id() -> str:
    return uuid.uuid4().hex


def stable_doc_id(source: str, content: str) -> str:
    h = hashlib.sha256()
    h.update(source.encode("utf-8"))
    h.update(b"\n")
    h.update(content.encode("utf-8", errors="ignore"))
    return h.hexdigest()[:24]


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

