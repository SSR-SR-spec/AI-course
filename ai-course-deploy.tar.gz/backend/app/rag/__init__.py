"""RAG package (ingest, index, retrieve)."""

