from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    text: str
    meta: dict


def chunk_text(
    text: str,
    *,
    chunk_size: int = 900,
    chunk_overlap: int = 150,
) -> list[Chunk]:
    """
    Simple character chunking with overlap.
    For campus policies, this is a robust baseline and works for mixed docs.
    """
    clean = text.strip()
    if not clean:
        return []

    chunks: list[Chunk] = []
    start = 0
    idx = 0
    while start < len(clean):
        end = min(len(clean), start + chunk_size)
        piece = clean[start:end]
        chunk_id = f"c{idx:06d}"
        chunks.append(Chunk(chunk_id=chunk_id, text=piece, meta={"start": start, "end": end}))
        idx += 1
        if end == len(clean):
            break
        start = max(0, end - chunk_overlap)
    return chunks

