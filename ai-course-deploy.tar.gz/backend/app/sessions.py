from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Literal

from app.utils import ensure_dir, now_ms


Role = Literal["user", "assistant", "system"]


@dataclass(frozen=True)
class StoredMessage:
    role: Role
    content: str
    ts_ms: int


class FileSessionStore:
    """
    Minimal persistence for chat history.
    Stores one JSONL file per session_id under `base_dir/sessions/`.
    """

    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.sessions_dir = os.path.join(base_dir, "sessions")
        ensure_dir(self.sessions_dir)

    def _path(self, session_id: str) -> str:
        safe = "".join(ch for ch in session_id if ch.isalnum() or ch in ("_", "-", "."))
        if not safe:
            safe = "default"
        return os.path.join(self.sessions_dir, f"{safe}.jsonl")

    def append(self, session_id: str, role: Role, content: str) -> None:
        p = self._path(session_id)
        ensure_dir(os.path.dirname(p))
        msg = {"role": role, "content": content, "ts_ms": now_ms()}
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(msg, ensure_ascii=False) + "\n")

    def load_tail(self, session_id: str, *, max_messages: int) -> list[StoredMessage]:
        p = self._path(session_id)
        if not os.path.exists(p):
            return []
        # Simple approach: read all and take tail (fine for course/demo scale).
        msgs: list[StoredMessage] = []
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    msgs.append(
                        StoredMessage(
                            role=obj["role"],
                            content=obj["content"],
                            ts_ms=int(obj.get("ts_ms", 0) or 0),
                        )
                    )
                except Exception:
                    continue
        return msgs[-max_messages:]

    def clear(self, session_id: str) -> None:
        p = self._path(session_id)
        if os.path.exists(p):
            os.remove(p)

